package com.dwarkesh.pricelist;

import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.ContentValues;
import android.content.ClipData;
import android.content.Intent;
import android.content.Context;
import android.graphics.Color;
import android.print.PrintManager;
import android.print.PrintAttributes;
import android.speech.RecognizerIntent;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.util.Base64;
import android.view.ViewGroup;
import android.webkit.JavascriptInterface;
import android.webkit.MimeTypeMap;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.print.PrintDocumentAdapter;
import android.webkit.WebViewClient;
import android.webkit.ValueCallback;
import android.widget.Toast;

import androidx.core.content.FileProvider;
import androidx.webkit.WebViewAssetLoader;

import org.json.JSONObject;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.util.ArrayList;

public class MainActivity extends Activity {
    private static final int PICK_FILES = 501;
    private static final int REQUEST_GUJARATI_VOICE = 502;
    private static final String HOME = "https://appassets.androidplatform.net/assets/index.html";
    private WebView web;
    private ValueCallback<Uri[]> fileCallback;
    private Uri cameraUri;

    private WebViewAssetLoader assets;

    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        assets = new WebViewAssetLoader.Builder()
            .addPathHandler("/assets/", new WebViewAssetLoader.AssetsPathHandler(this))
            .build();
        getWindow().setStatusBarColor(Color.rgb(11,22,39));
        getWindow().setNavigationBarColor(Color.rgb(11,22,39));

        web = new WebView(this);
        web.setLayoutParams(new ViewGroup.LayoutParams(-1,-1));
        setContentView(web);
        WebSettings ws = web.getSettings();
        ws.setJavaScriptEnabled(true);
        ws.setDomStorageEnabled(true);
        ws.setAllowFileAccess(false);
        ws.setAllowContentAccess(true);
        ws.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        ws.setJavaScriptCanOpenWindowsAutomatically(false);
        ws.setSupportMultipleWindows(false);
        ws.setBuiltInZoomControls(false);
        ws.setDisplayZoomControls(false);
        web.addJavascriptInterface(new NativeBridge(), "DwarkeshAndroid");

        web.setWebViewClient(new WebViewClient() {
            @Override public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
                return assets.shouldInterceptRequest(request.getUrl());
            }
            @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                Uri u = request.getUrl();
                if ("appassets.androidplatform.net".equalsIgnoreCase(u.getHost()) && "https".equals(u.getScheme())) return false;
                launchExternal(u.toString());
                return true;
            }
        });
        web.setWebChromeClient(new WebChromeClient() {
            @Override public boolean onShowFileChooser(WebView w, ValueCallback<Uri[]> callback, FileChooserParams params) {
                if (fileCallback != null) fileCallback.onReceiveValue(null);
                fileCallback=callback;
                Intent pick = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                pick.addCategory(Intent.CATEGORY_OPENABLE);
                pick.setType("*/*");
                pick.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
                pick.putExtra(Intent.EXTRA_MIME_TYPES,new String[]{
                    "image/*","application/pdf","text/*","application/json",
                    "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                    "application/vnd.ms-excel", "application/octet-stream"
                });
                Intent chooser = Intent.createChooser(pick,"પ્રાઇસલિસ્ટ અથવા ફોટો પસંદ કરો");
                try {
                    File d = new File(getExternalFilesDir(Environment.DIRECTORY_PICTURES), "camera_"+System.currentTimeMillis()+".jpg");
                    if (d.getParentFile()!=null) d.getParentFile().mkdirs();
                    if (d.createNewFile()) {
                        cameraUri = FileProvider.getUriForFile(MainActivity.this,
                            getPackageName()+".fileprovider",d);
                        Intent camera=new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
                        camera.putExtra(MediaStore.EXTRA_OUTPUT,cameraUri);
                        camera.setClipData(ClipData.newUri(getContentResolver(),"Camera destination",cameraUri));
                        camera.addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION | Intent.FLAG_GRANT_READ_URI_PERMISSION);
                        chooser.putExtra(Intent.EXTRA_INITIAL_INTENTS,new Intent[]{camera});
                    }
                } catch(Exception ignored) { cameraUri=null; }
                try {startActivityForResult(chooser,PICK_FILES);return true;}
                catch(Exception e) {fileCallback=null;callback.onReceiveValue(null);notice("ફાઇલ પિકર ખોલવામાં સમસ્યા");return false;}
            }
        });
        web.loadUrl(HOME);
    }

    @Override protected void onActivityResult(int req,int result,Intent data) {
        super.onActivityResult(req,result,data);
        if(req==REQUEST_GUJARATI_VOICE){
            if(result==RESULT_OK && data!=null){
                ArrayList<String> words=data.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS);
                if(words!=null && !words.isEmpty()){
                    String value=JSONObject.quote(words.get(0));
                    web.evaluateJavascript("window.dwarkeshVoiceResult("+value+")",null);
                }
            }
            return;
        }
        if(req!=PICK_FILES || fileCallback==null) return;
        ArrayList<Uri> uris=new ArrayList<>();
        if(result==RESULT_OK) {
            if(data!=null) {
                if(data.getClipData()!=null) {
                    for(int i=0;i<data.getClipData().getItemCount();i++)
                        uris.add(data.getClipData().getItemAt(i).getUri());
                } else if(data.getData()!=null) uris.add(data.getData());
            }
            if(uris.isEmpty() && cameraUri!=null) uris.add(cameraUri);
        }
        fileCallback.onReceiveValue(uris.isEmpty()?null:uris.toArray(new Uri[0]));
        fileCallback=null;cameraUri=null;
    }

    private void notice(String msg) {runOnUiThread(()->Toast.makeText(this,msg,Toast.LENGTH_LONG).show());}

    private void launchExternal(String address) {
        try {
            Uri u=Uri.parse(address);
            String scheme=u.getScheme();
            if(scheme==null || !(scheme.equalsIgnoreCase("https") || scheme.equalsIgnoreCase("http") ||
                scheme.equalsIgnoreCase("mailto") || scheme.equalsIgnoreCase("tel") ||
                scheme.equalsIgnoreCase("whatsapp"))) return;
            Intent i=new Intent(Intent.ACTION_VIEW,u);
            i.addCategory(Intent.CATEGORY_BROWSABLE);
            startActivity(i);
        } catch(Exception ex) {notice("આ લિંક ખોલવા માટે એપ ઉપલબ્ધ નથી");}
    }

    public class NativeBridge {
        @JavascriptInterface public void startVoiceSearch(){
            runOnUiThread(()->{
                try{
                    Intent intent=new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
                    intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
                    intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE,"gu-IN");
                    intent.putExtra(RecognizerIntent.EXTRA_PROMPT,"ગુજરાતીમાં મોડલ અથવા પ્રોડક્ટ બોલો");
                    startActivityForResult(intent,REQUEST_GUJARATI_VOICE);
                }catch(Exception ex){notice("ગુજરાતી વોઇસ સર્ચ માટે Google Speech app જરૂરી છે");}
            });
        }
        @JavascriptInterface public void printPage(){
            runOnUiThread(()->{
                try{
                    PrintManager pm=(PrintManager)getSystemService(Context.PRINT_SERVICE);
                    PrintDocumentAdapter ad=web.createPrintDocumentAdapter("Dwarkesh_Quotation");
                    pm.print("Dwarkesh Enterprise Quotation",ad,new PrintAttributes.Builder().build());
                }catch(Exception ex){notice("Quotation PDF / Print ખુલ્યું નથી: "+ex.getMessage());}
            });
        }
        private byte[] parse(String base64) {
            byte[] bytes=Base64.decode(base64, Base64.DEFAULT);
            if(bytes.length>18*1024*1024) throw new IllegalArgumentException("File too large");
            return bytes;
        }
        private String filename(String s) {
            if(s==null || s.isEmpty()) return "Dwarkesh_File";
            return s.replaceAll("[^a-zA-Z0-9._-]","_").replaceAll("^\\.+","file_");
        }
        @JavascriptInterface public void openExternal(String url) {runOnUiThread(()->launchExternal(url));}
        @JavascriptInterface public void saveBase64(String encoded,String mime,String name) {
            new Thread(()->{
                try {
                    byte[] bytes=parse(encoded);
                    String file=filename(name);
                    ContentValues cv=new ContentValues();
                    cv.put(MediaStore.MediaColumns.DISPLAY_NAME,file);
                    cv.put(MediaStore.MediaColumns.MIME_TYPE,mime.split(";")[0]);
                    cv.put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS+"/DwarkeshAI");
                    cv.put(MediaStore.MediaColumns.IS_PENDING,1);
                    Uri uri=getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI,cv);
                    if(uri==null) throw new IOException("Download storage unavailable");
                    try(OutputStream os=getContentResolver().openOutputStream(uri)){
                        if(os==null) throw new IOException("File write refused");
                        os.write(bytes);
                    }
                    cv.clear();cv.put(MediaStore.MediaColumns.IS_PENDING,0);
                    getContentResolver().update(uri,cv,null,null);
                    notice("Downloads/DwarkeshAI માં સેવ થઈ ગયું ✅");
                } catch(Exception ex){notice("સેવ ન થયું: "+ex.getMessage());}
            }).start();
        }
        @JavascriptInterface public void shareBase64(String encoded,String mime,String name,String caption) {
            new Thread(()->{
                try {
                    byte[] bytes=parse(encoded);
                    File folder = new File(getCacheDir(),"shared");
                    if(!folder.exists()) folder.mkdirs();
                    File f=new File(folder,filename(name));
                    try(FileOutputStream o=new FileOutputStream(f)){o.write(bytes);}
                    Uri uri=FileProvider.getUriForFile(MainActivity.this,getPackageName()+".fileprovider",f);
                    runOnUiThread(()->{
                        Intent send=new Intent(Intent.ACTION_SEND);
                        send.setType(mime);
                        send.putExtra(Intent.EXTRA_STREAM,uri);
                        send.putExtra(Intent.EXTRA_TEXT,caption);
                        send.setClipData(ClipData.newUri(getContentResolver(),"Product photo",uri));
                        send.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                        try {startActivity(Intent.createChooser(send,"WhatsApp પર પ્રોડક્ટ મોકલો"));}
                        catch(Exception e){notice("WhatsApp શેર મેનુ ખુલ્યું નથી");}
                    });
                }catch(Exception ex){notice("ફોટો શેર ન થયો: "+ex.getMessage());}
            }).start();
        }
    }

    @Override public void onBackPressed() {
        if(web.canGoBack()) web.goBack(); else super.onBackPressed();
    }
    @Override protected void onDestroy() {
        if(web!=null){web.removeJavascriptInterface("DwarkeshAndroid");web.destroy();}
        super.onDestroy();
    }
}
