-- DWARKESH ENTERPRISE V9: Run once in the SAME existing Supabase project SQL Editor.
-- This is additive. Does not alter V8 products, rates, users, or admin workspace.
create table if not exists public.crm_leads (
  workspace_id uuid not null references public.workspaces(id) on delete cascade,
  lead_id text not null check (length(lead_id) between 1 and 150),
  customer_name text not null check (length(customer_name) between 1 and 180),
  phone text not null check (length(phone) between 10 and 18),
  interest text not null default '',
  status text not null default 'New' check (status in ('New','Contacted','Interested','Quotation Sent','Follow-up','Won','Lost')),
  source text not null default 'Walk-in',
  followup_at timestamptz,
  note text not null default '',
  optin boolean not null default false,
  last_inbound_at timestamptz,
  created_by uuid references auth.users(id) on delete set null,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  primary key (workspace_id,lead_id)
);
create index if not exists crm_leads_workspace_phone_idx on public.crm_leads(workspace_id,phone);
create index if not exists crm_leads_followup_idx on public.crm_leads(workspace_id,followup_at);
alter table public.crm_leads enable row level security;
revoke all on table public.crm_leads from anon;
grant select,insert,update,delete on table public.crm_leads to authenticated;

drop policy if exists crm_leads_select on public.crm_leads;
create policy crm_leads_select on public.crm_leads for select to authenticated
 using (public.role_for_workspace(workspace_id) in ('admin','staff'));
drop policy if exists crm_leads_insert on public.crm_leads;
create policy crm_leads_insert on public.crm_leads for insert to authenticated
 with check (public.role_for_workspace(workspace_id) in ('admin','staff'));
drop policy if exists crm_leads_update on public.crm_leads;
create policy crm_leads_update on public.crm_leads for update to authenticated
 using (public.role_for_workspace(workspace_id) in ('admin','staff'))
 with check (public.role_for_workspace(workspace_id) in ('admin','staff'));
drop policy if exists crm_leads_delete on public.crm_leads;
create policy crm_leads_delete on public.crm_leads for delete to authenticated
 using (public.role_for_workspace(workspace_id) = 'admin');
-- Verify: select count(*) from public.crm_leads;
-- Never share service_role credentials or real customer contact data publicly.
