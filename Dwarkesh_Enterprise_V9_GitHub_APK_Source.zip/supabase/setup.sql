-- DWARKESH ENTERPRISE V8 • Supabase SQL Editor • run once as project owner.
-- Enable Email/Password under Authentication > Providers. Do not put service_role in the app.
create extension if not exists pgcrypto;

create table if not exists public.workspaces (
  id uuid primary key default gen_random_uuid(),
  name text not null check (length(name) between 2 and 150),
  owner_id uuid not null references auth.users(id) on delete cascade,
  created_at timestamptz not null default now()
);
create table if not exists public.members (
  workspace_id uuid not null references public.workspaces(id) on delete cascade,
  user_id uuid not null references auth.users(id) on delete cascade,
  role text not null check (role in ('admin','staff')),
  created_at timestamptz not null default now(),
  primary key(workspace_id,user_id)
);
create table if not exists public.public_products (
  workspace_id uuid not null references public.workspaces(id) on delete cascade,
  product_key text not null,
  payload jsonb not null check(jsonb_typeof(payload)='object' and not (payload ?| array['dealer','buyPrice','purchasePrice','costPrice','profit','supplierPrice'])),
  updated_at timestamptz not null default now(),
  primary key(workspace_id,product_key)
);
create table if not exists public.private_prices (
  workspace_id uuid not null references public.workspaces(id) on delete cascade,
  product_key text not null,
  dealer numeric(14,2),
  updated_at timestamptz not null default now(),
  primary key(workspace_id,product_key)
);
create table if not exists public.business_profiles (
  workspace_id uuid primary key references public.workspaces(id) on delete cascade,
  profile jsonb not null default '{}'::jsonb,
  updated_at timestamptz not null default now()
);

create or replace function public.role_for_workspace(p_workspace uuid)
returns text language sql stable security definer set search_path = public, pg_temp as $$
  select m.role from public.members m
  where m.workspace_id = p_workspace and m.user_id = (select auth.uid()) limit 1;
$$;
revoke all on function public.role_for_workspace(uuid) from public;
grant execute on function public.role_for_workspace(uuid) to authenticated;

alter table public.workspaces enable row level security;
alter table public.members enable row level security;
alter table public.public_products enable row level security;
alter table public.private_prices enable row level security;
alter table public.business_profiles enable row level security;

-- Explicitly drop/recreate allows editing policies on reinstall. Only authenticated users receive table grants.
drop policy if exists workspace_read on public.workspaces;
create policy workspace_read on public.workspaces for select to authenticated
 using (public.role_for_workspace(id) in ('admin','staff'));
drop policy if exists member_read on public.members;
create policy member_read on public.members for select to authenticated
 using (public.role_for_workspace(workspace_id) in ('admin','staff'));
drop policy if exists public_product_read on public.public_products;
create policy public_product_read on public.public_products for select to authenticated
 using (public.role_for_workspace(workspace_id) in ('admin','staff'));
drop policy if exists public_product_write on public.public_products;
create policy public_product_write on public.public_products for all to authenticated
 using (public.role_for_workspace(workspace_id)='admin')
 with check (public.role_for_workspace(workspace_id)='admin');
drop policy if exists private_price_admin on public.private_prices;
create policy private_price_admin on public.private_prices for all to authenticated
 using (public.role_for_workspace(workspace_id)='admin')
 with check (public.role_for_workspace(workspace_id)='admin');
drop policy if exists business_profile_read on public.business_profiles;
create policy business_profile_read on public.business_profiles for select to authenticated
 using (public.role_for_workspace(workspace_id) in ('admin','staff'));
drop policy if exists business_profile_write on public.business_profiles;
create policy business_profile_write on public.business_profiles for all to authenticated
 using (public.role_for_workspace(workspace_id)='admin')
 with check (public.role_for_workspace(workspace_id)='admin');

revoke all on public.workspaces,public.members,public.public_products,public.private_prices,public.business_profiles from anon;
grant select on public.workspaces,public.members to authenticated;
grant select,insert,update,delete on public.public_products,public.private_prices,public.business_profiles to authenticated;

create or replace function public.create_workspace(p_name text) returns uuid
language plpgsql security definer set search_path = public, pg_temp as $$
declare v_id uuid;
begin
 if auth.uid() is null then raise exception 'Login required'; end if;
 if length(trim(p_name))<2 or length(p_name)>150 then raise exception 'Invalid workspace name'; end if;
 insert into public.workspaces(name,owner_id) values(trim(p_name),auth.uid()) returning id into v_id;
 insert into public.members(workspace_id,user_id,role) values(v_id,auth.uid(),'admin');
 return v_id;
end;
$$;
revoke all on function public.create_workspace(text) from public;
grant execute on function public.create_workspace(text) to authenticated;

-- A staff member must sign up and verify their email first. Only an existing workspace owner can add them.
create or replace function public.add_staff_by_email(p_workspace uuid,p_email text) returns void
language plpgsql security definer set search_path = public, pg_temp as $$
declare v_staff uuid;
begin
 if auth.uid() is null then raise exception 'Login required'; end if;
 if not exists(select 1 from public.workspaces w where w.id=p_workspace and w.owner_id=auth.uid()) then
  raise exception 'Only workspace owner may add staff';
 end if;
 select u.id into v_staff from auth.users u
 where lower(u.email)=lower(trim(p_email)) and u.email_confirmed_at is not null limit 1;
 if v_staff is null then raise exception 'User must sign up and confirm email first'; end if;
 insert into public.members(workspace_id,user_id,role) values(p_workspace,v_staff,'staff')
 on conflict (workspace_id,user_id) do update set role='staff'
 where public.members.role<>'admin';
end;
$$;
revoke all on function public.add_staff_by_email(uuid,text) from public;
grant execute on function public.add_staff_by_email(uuid,text) to authenticated;

-- Verify after setup: Staff cannot SELECT private_prices or INSERT public_products.
-- If an owner leaves, revoke their membership using the SQL Editor, not from a staff device.
