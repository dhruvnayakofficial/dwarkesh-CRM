// Future secure outbound sender: WhatsApp token is a SERVER SECRET, never in Android.
import {createClient} from 'https://esm.sh/@supabase/supabase-js@2';
const env=(key:string)=>Deno.env.get(key)||'';
const json=(x:unknown,status=200)=>new Response(JSON.stringify(x),{status,headers:{'content-type':'application/json'}});
Deno.serve(async(req:Request)=>{
 if(req.method!=='POST')return json({error:'Method not allowed'},405);
 try{
  const auth=req.headers.get('Authorization')||'';
  if(!auth.startsWith('Bearer '))return json({error:'Login required'},401);
  const anon=createClient(env('SUPABASE_URL'),env('SUPABASE_ANON_KEY'),{global:{headers:{Authorization:auth}}});
  const {data:ident,error:uErr}=await anon.auth.getUser(auth.slice(7));if(uErr||!ident.user)return json({error:'Invalid session'},401);
  const {workspaceId,leadId,message,templateName,templateLang}=await req.json();
  if(!workspaceId||!leadId)return json({error:'Workspace and Lead required'},400);
  const {data:member}=await anon.from('members').select('role').eq('workspace_id',workspaceId).eq('user_id',ident.user.id).maybeSingle();
  if(!member||!['admin','staff'].includes(member.role))return json({error:'Forbidden'},403);
  const {data:lead}=await anon.from('crm_leads').select('phone,optin,last_inbound_at').eq('workspace_id',workspaceId).eq('lead_id',leadId).maybeSingle();
  if(!lead)return json({error:'Lead not found'},404);
  if(!lead.optin)return json({error:'Customer WhatsApp opt-in not recorded'},403);
  const phone=String(lead.phone||'').replace(/\D/g,'');if(phone.length<11||phone.length>15)return json({error:'Invalid phone'},400);
  const within24h=lead.last_inbound_at&&(Date.now()-new Date(lead.last_inbound_at).getTime())<24*60*60*1000;
  let payload:any={messaging_product:'whatsapp',to:phone};
  if(templateName){if(!/^[A-Za-z0-9_]+$/.test(templateName))return json({error:'Invalid template'},400);
    payload={...payload,type:'template',template:{name:templateName,language:{code:templateLang||'en_US'}}};
  }else{
    if(!within24h)return json({error:'24h service window closed; approved template required'},409);
    if(!message||typeof message!=='string'||message.length>1500)return json({error:'Text message required (max 1500)'},400);
    payload={...payload,type:'text',text:{body:message,preview_url:false}};
  }
  const token=env('WA_ACCESS_TOKEN'),phoneId=env('WA_PHONE_NUMBER_ID'),v=env('WA_GRAPH_VERSION');
  if(!token||!phoneId||!/^v\d+\.\d+$/.test(v))return json({error:'WhatsApp API server not configured'},503);
  const response=await fetch(`https://graph.facebook.com/${v}/${encodeURIComponent(phoneId)}/messages`,{method:'POST',headers:{'content-type':'application/json',Authorization:`Bearer ${token}`},body:JSON.stringify(payload)});
  const body=await response.json();if(!response.ok)return json({error:'Meta API declined message',details:body.error?.message||'unknown'},502);
  return json({ok:true,messageId:body.messages?.[0]?.id||null});
 }catch(e){return json({error:'WhatsApp gateway request failed'},500)}
});
