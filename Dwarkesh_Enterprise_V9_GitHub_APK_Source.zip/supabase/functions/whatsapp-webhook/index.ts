// Deploy later, AFTER getting official Meta WhatsApp Cloud API credentials.
// Requires verify_jwt=false for this ONE public webhook function; HMAC validates POST.
import {createClient} from 'https://esm.sh/@supabase/supabase-js@2';
const env=(key:string)=>Deno.env.get(key)||'';
const cleanPhone=(p:string)=>p.replace(/\D/g,'');
const hex=(buf:ArrayBuffer)=>Array.from(new Uint8Array(buf)).map(x=>x.toString(16).padStart(2,'0')).join('');
async function validSignature(raw:string,provided:string,secret:string):Promise<boolean>{
 if(!secret||!provided.startsWith('sha256='))return false;
 const key=await crypto.subtle.importKey('raw',new TextEncoder().encode(secret),{name:'HMAC',hash:'SHA-256'},false,['sign']);
 const expected='sha256='+hex(await crypto.subtle.sign('HMAC',key,new TextEncoder().encode(raw)));
 const a=new TextEncoder().encode(expected),b=new TextEncoder().encode(provided);
 if(a.length!==b.length)return false;let diff=0;for(let i=0;i<a.length;i++)diff|=a[i]^b[i];return diff===0;
}
Deno.serve(async(req:Request)=>{
 try{
  if(req.method==='GET'){
   const q=new URL(req.url).searchParams;
   if(q.get('hub.mode')==='subscribe' && q.get('hub.verify_token')===env('WA_VERIFY_TOKEN'))return new Response(q.get('hub.challenge')||'',{status:200});
   return new Response('verification failed',{status:403});
  }
  if(req.method!=='POST')return new Response('Method not allowed',{status:405});
  const raw=await req.text();
  if(!await validSignature(raw,req.headers.get('x-hub-signature-256')||'',env('WA_APP_SECRET')))return new Response('bad signature',{status:401});
  const body=JSON.parse(raw);const workspace=env('DWARKESH_WORKSPACE_ID');
  if(!workspace)return new Response('Workspace unconfigured',{status:503});
  const supabase=createClient(env('SUPABASE_URL'),env('SUPABASE_SERVICE_ROLE_KEY'));
  for(const entry of (body.entry||[]))for(const change of(entry.changes||[])){
   const value=change.value||{};
   if(env('WA_PHONE_NUMBER_ID')&&value.metadata?.phone_number_id!==env('WA_PHONE_NUMBER_ID'))continue;
   for(const msg of (value.messages||[])){
    if(!msg.from||!msg.id)continue;
    const phone=cleanPhone(msg.from);if(phone.length<10||phone.length>15)continue;
    const {data:prior}=await supabase.from('crm_leads').select('lead_id').eq('workspace_id',workspace).eq('phone',phone).limit(1).maybeSingle();
    if(prior){await supabase.from('crm_leads').update({last_inbound_at:new Date().toISOString(),updated_at:new Date().toISOString()}).eq('workspace_id',workspace).eq('lead_id',prior.lead_id)}
    else{const name=(value.contacts?.find((x:any)=>x.wa_id===msg.from)?.profile?.name||'WhatsApp Customer').slice(0,180);
      await supabase.from('crm_leads').upsert({workspace_id:workspace,lead_id:'wa-'+phone,customer_name:name,phone,interest:(msg.text?.body||'New WhatsApp inquiry').slice(0,200),status:'New',source:'WhatsApp',optin:false,last_inbound_at:new Date().toISOString()}, {onConflict:'workspace_id,lead_id'});}
   }
  }
  // Deliberately no automatic AI reply until opted in and reviewed.
  return new Response('ok',{status:200});
 }catch(e){return new Response('Webhook error',{status:500})}
});
