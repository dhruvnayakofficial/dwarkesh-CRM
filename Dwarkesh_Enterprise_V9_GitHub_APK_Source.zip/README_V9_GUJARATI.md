# Dwarkesh Enterprise PriceList AI V9 – GitHub APK Setup (ગુજરાતી)

## V9 માં શું નવું છે?
- Leads CRM: ગ્રાહક, ફોન, Product Interested, Status, Next Follow-up, Note, Source, WhatsApp Click-to-Chat.
- WhatsApp Business API તૈયારી: Meta Phone Number ID, WABA ID, approved template setting અને સુરક્ષિત Supabase Edge Function source. API પ્રાપ્ત કરીને deploy કર્યા પહેલાં API Send સક્રિય નથી; ઓટોમેટિક જવાબો નથી.
- AI Chatbot: એપમાં લોકલ કૅટલોગ સર્ચ તરત ચાલે છે; વૈકલ્પિક Gemini API Reply. AIને માત્ર Customer Selling Price/સ્પેક્સ મોકલાય છે, Dealer Purchase Price નથી.
- ભાવની ભૂલ સુધારી: Excel/CSV/PDF અને Photo OCRમાં સામાન્ય Price/Rate ને Purchase/Dealer ગણે છે. સ્પષ્ટ Customer/Selling Price હેડર હોય તો જ ગ્રાહક ભાવ ગણે છે. Quotation, JPG Catalogue અને WhatsAppમાં Purchase ભાવનો fallback બંધ.
- Price Manager: મોડલવાર Customer Price, માર્કઅપ (₹ અને %), અને જૂના ભાવને Review કરીને Purchaseમાં ખસેડવાનો અલગ Confirm બટન.
- V9 JSON Backup માં Product, Business Profile, Leads. Key/Password/Token બેકઅપમાં નથી.
- અગાઉની V8ની Photo, Quotation, Stock, Business Profile, Admin/Staff, Cloud Sync સુવિધાઓ જાળવી છે.

## સૌથી મહત્વનું: V8ના 133 મોડલ અને Cloud ડેટા
V9નું Android application ID `com.dwarkesh.pricelist.v9` છે. V8થી *અલગ એપ* તરીકે ઇન્સ્ટોલ થશે. અમે આમ કર્યું છે કારણ કે અગાઉની V8 debug APKની signing key સાથે અલગ GitHub Buildની signing key સરખી ન હોઈ શકે; તેને in-place update કરવી જોખમી છે.
1. જૂની V8 APK **ક્યારેય Uninstall ન કરો**. V8 → Sales Hub → Backup → V8 Full Backup JSON બહાર સાચવો.
2. V8 → Cloud & Staff → Local Products → Cloud (જો Cloud Sync કરવાનો ઇરાદો હોય તો), સફળતા ચકાસો.
3. V9 APK ઇન્સ્ટોલ કરો. તેમાં Cloud URL/Publishable Key અને Admin Login ફરી ભરવું પડી શકે છે.
4. V9 → Backup → Restore જૂનો V8 JSON પસંદ કરો અથવા Cloud & Staff → Cloud → Local Merge (Cloudમાં Products Push થયા હોય તો).
5. V9 માં Product Count, Brand અને Price ચકાસો; V8 જાળવી રાખો. જૂના customer prices **આપમેળે બદલાતા નથી**.
6. ભૂલથી જૂના dealer-only ભાવ customer ગણાયા હોય તો **પહેલાં V9 Backup**, પછી Sales Hub → Purchase → Customer → “જૂના ભાવ Purchaseમાં ખસેડો” પસંદ કરો અને ખાતરી કરો. આ અસરવાળા મોડલમાં Customer Price ખાલી થાય છે; પછી અલગથી Selling Price સેટ કરો.

## GitHub પરથી APK બનાવવા
તમારી repository: https://github.com/dhruvnayakofficial/dwarkesh-CRM
1. આ પેકેજની `Dwarkesh_Enterprise_V9_GitHub_APK_Source.zip` ફાઇલ Repository rootમાં અપલોડ કરો (મૂળ V8 ZIP untouched રહે).
2. Repositoryમાં `.github/workflows/build.yml` ને સાથે આપેલી `build.yml` થી બદલો. Commit changes.
3. GitHub Actions → Build Dwarkesh Enterprise V9 APK → સફળ run → Artifacts → `Dwarkesh-Enterprise-V9-APK` ZIP ડાઉનલોડ કરો.
4. ZIP Extract → `app-debug.apk` → Android ફોનમાં Install કરો. V8 બાજુમાં V9 અલગ એપ રહેશે.
5. Debug APK ટેસ્ટિંગ માટે છે; ભવિષ્યના in-place updates માટે GitHub Secretsમાં પોતાની કાયમી Release Signing Key સેટ કરવી જોઈએ.

## Supabase V9 Leads SQL – એક જ વખત Run કરવાનું
તમારું પહેલેથી બન્યું V8 Supabase Project ફરી ન બનાવવું.
Supabase Dashboard → SQL Editor → New Query → પેકેજની `supabase/v9_leads_migration.sql` નું આખું SQL Paste → Run → Success.
આ migration માત્ર નવી `crm_leads` ટેબલ અને RLS rules ઉમેરે છે; V8 Products/Workspace/Private Dealer Rate બદલતું નથી.
V9માં Admin Login પછી Leads CRM → Leads → Cloud Push / Pull કરી શકો છો.

## WhatsApp API આવતીકાલે મળે ત્યારે
Meta Business Account અને Official Cloud API માં Phone Number ID, WABA ID અને approved message templates તૈયાર કરો.
Meta Access Token/Meta App Secretને **મોબાઇલ એપ કે Public GitHubમાં નાખશો નહીં**.
Supabase Edge Functionsમાં બે source templates છે: `whatsapp-webhook` (Inbound leads) અને `whatsapp-send` (permission checked outbound).
તમારે પછી Functions deploy કરવી પડશે; secrets `WA_ACCESS_TOKEN`, `WA_PHONE_NUMBER_ID`, `WA_GRAPH_VERSION`, `WA_APP_SECRET`, `WA_VERIFY_TOKEN`, `DWARKESH_WORKSPACE_ID` Supabase Secret Managerમાં સેટ કરવા પડશે.
`whatsapp-webhook` માટે Meta Webhook URL + verify token; public endpoint verify JWT OFF, પરંતુ HMAC signature ફરજિયાત. `whatsapp-send` માટે logged-in JWT ફરજિયાત છે.
એપમાં Meta ID દાખલ કરી શકાય છે, પરંતુ actual API credentials અને deployment વિના API Send કાર્યરત નહીં થાય.
Customer opt-in સાચવો. 24h inbound service windowની બહાર approved template જ મોકલો. WhatsApp AI automatic reply હજી જોડાયું નથી.

## Testing/Limitations
વેબ બ્રાઉઝર-સિમ્યુલેટેડ ટેસ્ટ: Lead Save, Local Chat, CSV price-as-purchase, Customer blank, Markup, JS syntax. Live Meta API, Gemini, Supabase network sync, GitHub compilation અને Android handset install **હજી ટેસ્ટ કરેલા નથી**. ગ્રાહકોને ભાવે મોકલતાં પહેલાં ચકાસો.
