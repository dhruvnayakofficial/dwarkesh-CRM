# Dwarkesh Enterprise — PriceList AI V8 Android

**Version:** V8.0 · Package: `com.dwarkesh.pricelist` · Android 10+.

## 1. GitHub પરથી APK Build (PC વગર પણ થઈ શકે)

1. GitHubમાં નવા **Private Repository** બનાવો — ઉદાહરણ `dwarkesh-enterprise-ai`.
2. આ ZIP **Extract** કરો. અંદરની ફાઇલો (`app/`, `.github/`, `build.gradle`, `settings.gradle`, `supabase/` વગેરે) repoના **root** માં અપલોડ કરો. ZIPને જેમ છે તેમ અપલોડ કરવાથી Action નહીં ચાલે. `.github` hidden folder પણ હોવો આવશ્યક છે.
3. GitHub repo → **Actions** → **Build Dwarkesh V8 Android APK** → **Run workflow** → workflow પૂર્ણ થયા બાદ **Artifacts** → `Dwarkesh-Enterprise-V8-APK` → ZIP ડાઉનલોડ કરો.
4. GitHubનું artifact ZIP **Extract** કરો → `app-debug.apk` મળશે. તેને Android ફોનમાં install કરો (જરૂર પડે તો Settings → Install unknown apps → Allow).
5. એપ ખોલો → 🚀 Sales Hub → 🏪 Business Details → તમારી દુકાનનું સરનામું/GST/ફોન ઉમેરો. આપેલો logo પહેલેથી છે.

**વાસ્તવિક APK અહીં compile થયું નથી:** આ વાત છુપાવવી નહીં. GitHub Actions build સમયે Gradle / SDK download થાય છે; build errors માટે Actions → Logs જુઓ. GitHub પર Private Repo રાખો. Debug APK testing/internal use માટે યોગ્ય છે, Play Store deployment માટે નહીં. Production release build માટે keystore/signing અને staged deployment જરૂરી છે.

> ⚠️ **Update / Data safety:** GitHub Actionsની અલગ runsમાં Debug Signing Certificate બદલાઈ શકે છે. જૂની APK પર નવી APK install ન થાય તો જૂની એપ uninstall કરતાં પહેલાં **V8 Full JSON Backup** લઈને સુરક્ષિત રીતે સાચવો. Uninstallથી App Data કાઢી શકે છે. Long-term માટે persistent release signing key જરૂરી છે.

## 2. જૂના 133 મોડલ બચાવો

- V6/V7 → Sales Hub → **💾 Backup** → Full JSON Backup, download to phone.
- V8 APKમાં → Sales Hub → **💾 Backup** → V6/V7/V8 Restore → JSON પસંદ કરો → Merge કરો.
- Restored model count/price/photo/specs તપાસો. V8 → Full Backup ફરી લઈ લો. **Auto transfer થતું નથી:** Chrome `content://downloads` અને APK અલગ storage છે. જૂની HTML/Chrome ડેટા ડિલીટ નહીં કરશો.
- V8 Backupમાં Business Details, product catalogue, import metadata, stock/quote history આવે છે. Gemini API Key અને Cloud Password/Session બેકઅપમાં સામેલ નથી.

## 3. હવે સ્થાનિક રીતે મળતી સુવિધા

- 55+ electronics categories, ફોટો OCR, Excel/CSV/text PDF import, મોડલ શોધ, Gemini આધારિત ફોટો/spec lookup (API limits apply).
- AI-like filtered finder, Gujarati Voice Search (speech service required), Product Comparison, Profit Calculator, Stock Ledger, WhatsApp ફોટાવાળા JPG Product Cards અને Multi-product Catalogue.
- **Business Details + આપેલો logo:** નામ, માલિક, ફોન, સરનામું, GSTIN, email, website, Instagram, UPI, bank, terms. Quotation અને Catalogue/Single Product card header/footerમાં લાગુ.
- Quotation માટે **Print → Save as PDF**; આ official GST Tax Invoice નથી.
- **સ્થાનિક મોડમાં ડેટા deviceમાં જ** રહે છે. બેકઅપ અનિવાર્ય.

## 4. Supabase Cloud Backup અને Staff/Admin Login સેટઅપ

Cloud માટે **તમારું Supabase project** જોઈએ, જે આ ZIPથી આપમેળે બનતું નથી:

1. Supabase Dashboardમાં project ખોલો, Authentication → Email Auth સક્રિય કરો.
2. **SQL Editor**માં `supabase/setup.sql` એક વખત ચલાવો. તેમાં `workspaces`, `members`, `public_products`, `private_prices`, `business_profiles`, RLS Policies અને secure RPC બને છે.
3. Project Settings → API માંથી **Project URL** તથા **Publishable/anon public API key** લો; **service_role / secret key ક્યારેય એપમાં નાખશો નહીં**.
4. V8 → Sales Hub → 🔐 Cloud & Staff → URL/key → Cloud Config Save → Email/Password **Signup**, email verify, પછી Login.
5. માલિક પહેલા Workspace બનાવે. **Admin** → Local Products → Cloud Push; Business Profile Sync. ત્યારબાદ Cloud → Local Merge કરી શકાય.
6. સ્ટાફ પોતાનાં **અલગ ફોન પર**, ખાલી એપ ડેટા સાથે Signup + Verify Email કરે. Admin તે Email ને Workspaceમાં Add Staff કરે. Staff Login કર્યા પછી Cloud Catalogue વાંચી શકે; server RLS તેને private dealer prices વાંચવા/બદલવા દેતું નથી.

### Cloud limits અને સુરક્ષા

- Cloud Sync હાલમાં **manual Push/Pull** છે, automatic background sync નહીં. Changes દરમિયાન simultaneous edit/conflict handling નથી; એક સમયે એક admin update કરવો.
- **Staff માટે Adminના ફોનનો local database અથવા જૂની JSON backup ન આપશો.** Cloud RLS server data સુરક્ષિત કરે છે; તમારા માલિકના ફોનમાં રહેલું offline dealer data તે સુરક્ષિત કરતું નથી. Cloud Staff માટે અલગ device પર clean install અનિવાર્ય.
- તસવીરોની મોટી Data URLs Cloud limit ટાળવા માટે skip થઈ શકે છે. ફોટા લોકલમાં જળવાય છે; share પહેલાં ચકાસો.
- Server-side Gemini proxy નથી: API Key તમારા Android WebView localStorageમાં રહે છે (encrypted નથી). ફક્ત વિશ્વસનીય Admin ફોનમાં વાપરો. Cloudમાં Key ન મોકલાય.
- Cloud registration, login, rate-limit, sync ચલાવવા Supabase account અને network જરૂરી છે. અહીં કોઈ જીવંત project/config credential નથી, તેથી live cloud login પરીક્ષણ થયું નથી.

## 5. જો GitHubમાં Upload તકલીફ પડે

Web GitHub Upload filesથી `.github` hidden directory ચૂકી શકે છે. GitHub Desktop અથવા `git add . && git commit && git push` વિશ્વસનીય રીત છે. GitHub Actions tabમાં workflowનું નામ દેખાય નહીં તો `.github/workflows/android-apk.yml` વાસ્તવમાં rootમાં છે તે તપાસો.

## 6. ટેસ્ટિંગની સ્થિતિ

V7ના finder, compare, margin, stock, catalogue અને quotation સ્થાનિક sample data પર ચકાસેલા છે. V8માં logo/profile/quotation/backup અને GitHub projectની static/browser tests અલગથી નોંધાયેલ છે. **Android APKનું આ કમ્પ્યુટરમાં actual Gradle compile કે તમારા ફોનમાં install ટેસ્ટ નથી થયું.** જો workflow fail થાય તો એની logથી સુધારવું પડશે.
