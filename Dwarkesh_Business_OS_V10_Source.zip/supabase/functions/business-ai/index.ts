import { createClient } from 'https://esm.sh/@supabase/supabase-js@2';
Deno.serve(async (req) => {
  const headers={'Content-Type':'application/json','Cache-Control':'no-store'};
  const reply=(status:number,body:unknown)=>new Response(JSON.stringify(body),{status,headers});
  if(req.method!=='POST')return reply(405,{error:'POST required'});
  const token=(req.headers.get('Authorization')||'').replace(/^Bearer\s+/i,'').trim();
  if(!token)return reply(401,{error:'Login required'});
  try{
    const url=Deno.env.get('SUPABASE_URL')||'', anon=Deno.env.get('SUPABASE_ANON_KEY')||'', key=Deno.env.get('GEMINI_API_KEY')||'';
    if(!url||!anon||!key)return reply(503,{error:'AI backend not configured'});
    const client=createClient(url,anon,{global:{headers:{Authorization:`Bearer ${token}`}},auth:{persistSession:false}});
    const {data:{user},error}=await client.auth.getUser(token);
    if(error||!user)return reply(401,{error:'Invalid session'});
    const arg=await req.json(),workspace=String(arg.workspace_id||''),q=String(arg.question||'').trim().slice(0,500);
    if(!/^[0-9a-f-]{36}$/i.test(workspace)||!q)return reply(400,{error:'Invalid request'});
    const {data:member,error:membershipError}=await client.from('members').select('role').eq('user_id',user.id).eq('workspace_id',workspace).maybeSingle();
    if(membershipError||!member||!['staff','admin'].includes(member.role))return reply(403,{error:'Not a workspace member'});
    const rows=Array.isArray(arg.catalog)?arg.catalog.slice(0,8):[];
    const catalog=rows.map((p:any)=>({brand:String(p.brand||'').slice(0,60),model:String(p.model||'').slice(0,90),category:String(p.category||'').slice(0,60),customerPrice:(Number(p.customerPrice)>0&&Number(p.customerPrice)<1e8)?Number(p.customerPrice):null,specs:String(p.specs||'').slice(0,250)}));
    const prompt=`Answer in Gujarati. You are the Dwarkesh Enterprise sales assistant. Use only supplied product facts. Never invent prices/specifications/stock or discuss hidden purchase costs. No suitable match means politely say no match. Request: ${q}\nProducts: ${JSON.stringify(catalog)}`;
    const model=Deno.env.get('GEMINI_MODEL')||'gemini-3.8-flash';
    const res=await fetch(`https://generativelanguage.googleapis.com/v1beta/models/${encodeURIComponent(model)}:generateContent`,{method:'POST',headers:{'Content-Type':'application/json','x-goog-api-key':key},body:JSON.stringify({contents:[{role:'user',parts:[{text:prompt}]}],generationConfig:{temperature:0.2,maxOutputTokens:600}}),signal:AbortSignal.timeout(18000)});
    const data=await res.json();if(!res.ok)return reply(502,{error:'Gemini request failed',status:res.status});
    const text=data?.candidates?.[0]?.content?.parts?.map((x:any)=>x.text||'').join('')||'';
    return reply(200,{answer:text.slice(0,2800),model});
  }catch{return reply(500,{error:'AI service unavailable'});}
});
