-- Dwarkesh Enterprise Business OS v10 — additive Cloud record store.
-- Run on the EXISTING Supabase project after V8 workspace + members migrations.
-- No existing products, users or leads are dropped or modified.
BEGIN;
CREATE TABLE IF NOT EXISTS public.os_records (
  workspace_id uuid NOT NULL REFERENCES public.workspaces(id) ON DELETE CASCADE,
  record_type text NOT NULL CHECK (record_type IN ('orders','expenses','suppliers','purchases','services','campaigns','referrals','tasks')),
  record_id text NOT NULL CHECK (length(record_id) BETWEEN 1 AND 128),
  body jsonb NOT NULL CHECK (jsonb_typeof(body)='object'),
  updated_at timestamptz NOT NULL DEFAULT now(),
  created_at timestamptz NOT NULL DEFAULT now(),
  PRIMARY KEY(workspace_id,record_type,record_id)
);
CREATE INDEX IF NOT EXISTS os_records_workspace_type_idx ON public.os_records(workspace_id,record_type,updated_at DESC);
ALTER TABLE public.os_records ENABLE ROW LEVEL SECURITY;
REVOKE ALL ON public.os_records FROM anon;
GRANT SELECT,INSERT,UPDATE,DELETE ON public.os_records TO authenticated;
DROP POLICY IF EXISTS os_member_read ON public.os_records;
CREATE POLICY os_member_read ON public.os_records FOR SELECT TO authenticated
USING (public.role_for_workspace(workspace_id) IN ('admin','staff'));
DROP POLICY IF EXISTS os_member_insert ON public.os_records;
CREATE POLICY os_member_insert ON public.os_records FOR INSERT TO authenticated
WITH CHECK (public.role_for_workspace(workspace_id) IN ('admin','staff'));
DROP POLICY IF EXISTS os_member_update ON public.os_records;
CREATE POLICY os_member_update ON public.os_records FOR UPDATE TO authenticated
USING (public.role_for_workspace(workspace_id) IN ('admin','staff'))
WITH CHECK (public.role_for_workspace(workspace_id) IN ('admin','staff'));
DROP POLICY IF EXISTS os_admin_delete ON public.os_records;
CREATE POLICY os_admin_delete ON public.os_records FOR DELETE TO authenticated
USING (public.role_for_workspace(workspace_id)='admin');
COMMIT;
-- NOTE: OS record bodies contain commercial and customer data; Staff members
-- currently have workspace access. Review this policy before adding untrusted staff.
-- WhatsApp and Gemini secrets must remain in Supabase Edge Function Secrets only.
