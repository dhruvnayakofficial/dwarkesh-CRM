# Dwarkesh Enterprise AI V9.2 — માસિક પ્રાઇસલિસ્ટ

## નવું શું છે?

- હવે દરેક **Excel / CSV / PDF / ફોટો પ્રાઇસલિસ્ટ** અપલોડ કરતા પહેલાં **મહિનો** પસંદ કરો.
- `October 2026` અને `November 2026` અલગ Batch તરીકે સાચવાય છે.
- મહિનાની બધી ફાઇલો **એક જ વખત Preview કરીને Delete** કરી શકાય છે.
- જો `SAMSUNG UA43...` બંને મહિનામાં હોય, તો October Delete કરતાં **Novemberનું મોડલ અને તેનો નવો Purchase Rate ચાલુ રહેશે**.
- માત્ર Octoberમાં આવેલા મોડલ જ કાઢી શકાય છે. પહેલેથી હાજર Manual/Legacy મોડલ માટે પહેલા Backup રાખો.
- મહિના Delete કરતાં પહેલાં **કેટલા દૂર થશે, કેટલા બીજા મહિનાના બચશે, અને કેટલા Legacy પાછા આવશે** બતાવે છે.
- **Full JSON Backup** માં માસિક બૅચની યાદી અને તેની snapshot પણ આવે છે.
- જૂના V8/V9/V9.1માં Import થયેલા મોડલને જાતે `જૂની ફાઇલને મહિનો આપો` દ્વારા ગ્રુપ કરી શકાય છે. જૂના મોડલ જાતે માસિક Delete માટે પસંદ ન કરો ત્યાં સુધી યથાવત રહેશે.
- Purchase/Dealer Price અને Customer Selling Price અલગ રહે છે. Sales CRM, AI Chat, Supabase Login, WhatsApp ફંક્શન V9.1માંથી જાળવ્યા છે.

## ઉપયોગ — ઉદાહરણ

1. **⚙️ Settings & PriceList → 🗓 આ પ્રાઇસલિસ્ટ કયા મહિનાની છે?** માં `2026-10` પસંદ કરો.
2. `October_PriceList.xlsx` ઉમેરો.
3. પછી `2026-11` પસંદ કરો અને `November_PriceList.xlsx` ઉમેરો.
4. ઉપરના **🗓 માસિક પ્રાઇસલિસ્ટ** ટૅબ ખોલો.
5. Octoberના કાર્ડમાં **જુઓ / Delete** દબાવો.
6. પહેલાં **⬇️ સંપૂર્ણ Monthly Backup** લઈને Downloadsમાં ખાતરી કરો.
7. Delete Previewમાં October-only મોડલનો આંકડો ચકાસી Checkbox પસંદ કરો અને Confirm કરો.
8. October-only મોડલ દૂર થશે; બંને મહિનામાં હોય તે મોડલ Novemberના ભાવ સાથે ચાલુ રહેશે.

## Cloud માટે મહત્વપૂર્ણ

- માસિક Delete **સૌ પ્રથમ આ ફોનના Local Database** માં થાય છે. Supabase Cloudનો ડેટા આપમેળે ડિલીટ થતો નથી.
- નવાં માસિક Batchથી લોડ થયેલા પ્રોડક્ટ્સને Admin **Local Products → Cloud** કરીને Upload કરે ત્યારે Public Product payloadમાં માસિક Batch ID પણ જાય છે, પણ Purchase/Dealer Rate હંમેશા અલગ private_pricesમાં રહે છે.
- માસિક Delete થયા પછી **☁️ Safe Cloud Cleanup** ફક્ત એ Batch ID સાથે ઓળખાતા અને સ્થાનિક નવા મહિનામાં બચેલા ન હોય તેવા મોડલ માટે Cloud Deleteની વિનંતી કરે છે. Delete કરતાં પહેલાં બીજી પુષ્ટિ લે છે.
- **જૂના V8/V9 Cloud રેકોર્ડમાં Batch ID નહોતું;** તેથી તે Safe Cloud Cleanup દ્વારા કાઢવામાં નહીં આવે. તેમને જાતે ચકાસીને અલગથી સુધારવું પડશે.
- જો October Delete પછી Novemberનો Purchase/Customer Price Cloudમાં અપડેટ કરવો હોય તો Admin **Local Products → Cloud** ફરી દબાવો. Cloud → Local Merge પહેલાં Pending Deleteની ચેતવણી વાંચો.
- Staffના ફોનમાં પણ જૂના Cloud મોડલ હોઈ શકે, જ્યાં સુધી યોગ્ય Cloud Cleanup અને Staff Catalogue refresh ન થાય.

## જૂના 133 મોડલ, ભાવ અને APK

- V9/V9.1 **Uninstall ન કરશો**. પહેલાં મૂળ એપમાંથી Full JSON Backup લો.
- V9.2 એ **અલગ ટેસ્ટ APK** છે, App ID `com.dwarkesh.pricelist.v92`; Android Debug Signing દરેક Build પર બદલાઈ શકે છે. એટલે જૂની એપ પરથી સીધું Update નહીં પરંતુ નવી એપ તરીકે Install થશે.
- V9.2માં Admin Supabase Config → Login કરો; Cloudમાં મોડલ હોય તો Cloud → Local Merge કરો; નથી તો જૂનો JSON Restore કરો.
- જૂના આયાત થયેલા Productsને માસિક લિસ્ટ માટે જબરદસ્તી Delete ન કરશો. જો `source` મૂળ Excel/PDFનું filename હોય તો **જૂની ફાઇલને મહિનો આપો** માંથી જ જોડો.
- **હાલની V9.2માં માસિક બૅચનું Cloud Backup અલગથી નથી** — માસિક Snapshot માટે Full JSON Backup જરૂરી છે. Supabaseમાં Product અને Rate sync થાય છે, પરંતુ માસિક Batch Snapshot માત્ર લોકલમાં છે.

## GitHubથી APK

1. `Dwarkesh_Enterprise_V9_2_GitHub_APK_Source.zip` GitHub Repositoryના rootમાં **ZIP જ** Upload કરો (Extract ન કરો).
2. `.github/workflows/build.yml` માટે આપેલી `Dwarkesh_V9_2_build.yml` ફાઇલનો કોડ Paste કરીને Commit કરો.
3. Actions → `Build Dwarkesh Enterprise V9.2 APK` → સફળ Runમાં `Dwarkesh-Enterprise-V9-2-APK` Artifact મળશે.
4. ZIP Extract કરીને `app-debug.apk` Install કરો.

## ચકાસણી

JavaScript syntax અને નીચેના ડેટા-લૉજિક કેસ ટેસ્ટ કર્યા: (a) October + Novemberમાં Same Model, October Delete પછી November Rate જળવાયો; (b) November Delete પછી October Rate પાછો આવ્યો; (c) અગાઉનો Manual Model માસિક Import કાઢતાં પાછો આવ્યો. Actual APK Build/Android phone test હજી બાકી છે.
