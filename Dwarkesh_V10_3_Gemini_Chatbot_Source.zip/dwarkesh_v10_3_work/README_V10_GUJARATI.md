# Dwarkesh Enterprise AI Business OS — Unified V10

આ Android Source Project અગાઉની **Dwarkesh Enterprise V9.2** એપ પરથી બનાવેલું additive upgrade છે. જુદી નવી Product એપ નહીં. Android App ID: `com.dwarkesh.pricelist.v9` (V9 સાથે એકસરખું), versionCode: 20. **GitHub પર આ Versionનું APK હજી Build/Install Test કરેલું નથી.**

## 1) વાસ્તવમાં કયા ફંક્શન છે?

### પહેલેથી રહેલા અને જાળવેલા ફંક્શન
- બધી Electronics કેટેગરી, Brand / partial Model / Size search; Photo/Excel/CSV/PDF PriceList import (ફાઇલ મુજબ OCR/API મર્યાદા)
- Monthly PriceList Manager, October→November overlap અને સુરક્ષિત local delete, product comparison, quotations, price list photo card, WhatsApp manual share
- Purchase Price અને Customer Selling Price અલગ, Margin Calculator, basic Stock Management
- Leads CRM, Follow-up, Gemini client chatbot (જૂનું), Business Details/Logo, Supabase Admin/Staff Login અને existing manual cloud product sync
- Gujarati Voice Search જ્યાં Android/webview સપોર્ટ આપે છે.

### V10માં નવા **વર્કિંગ લોકલ** modules (Growth OS tab)
- Business Overview: Products, Leads, Recorded Sales, Receivables, Follow-ups, Low Stock (માત્ર Local/loaded Data)
- **Vyapar Excel/CSV Import**: Header column mapping, Preview, Purchase Price mapped to Dealer, Customer Selling Rate OFF by default, Stock OFF by default, manual approval, no auto deletion
- Sales Order / Received Payment records, downloadable CSV (review file), printable sales statement **NOT a GST invoice**
- Supplier Purchase Register / Received status / export CSV
- Service & AMC Ticket: appointment/due date, technician, reminder via manual WhatsApp, CSV
- Campaign spend/leads/revenue capture, ROAS, manual Google Reviews/Referral WhatsApp drafts
- Tasks/follow-ups due, task close / WhatsApp draft, data-driven business command responses
- Growth OS JSON Backup/Restore; Supabase os_records SQL setup પછી manual Push/Pull Merge
- Staff/Admin માટે Gemini API secret server-side રાખવા `supabase/functions/business-ai` **deployable code** અને Growth OSમાં Cloud Gemini button

### હજી Third-party setup / વધારાનું development જરૂરી છે
- Vyapar **automatic real-time two-way API sync**: Vyapar પાસેથી અધિકૃત API મળે અને contract/permissions મળે ત્યારે જ.
- WhatsApp automatic AI reply / proactive reminders: Meta Cloud API, valid customer opt-in, templates, webhook, secrets, server, live tests જોઈએ.
- Secure AI production usage limits, prompt logs, purchase-price leak testing, cross-device real-time conflict management અને offline cross-device reconciliation: હજુ production-ready નથી.
- Fully automated GST invoicing: Vyaparમાં જ generate કરવું. Exported sales CSV એ GST invoice નથી.
- Barcode scanning, QR Storefront, ML-based loss/win prediction, advanced online campaign integrations, full audit trail, and automated Google reviews are roadmap items—not deployed as production systems.

90 ideasમાંથી ઘણા અત્યારે Workflow/roadmap છે. એક સાથે સંકલિત Source બનેલું છે, 90 production integrations તૈયાર થયાં નથી.

## 2) એ જ એપમાં Update કરવા પહેલાં આ વાંચવું મહત્વપૂર્ણ છે

જૂની V9 app ID `com.dwarkesh.pricelist.v9` છે. જૂની V9.2 demo ID `com.dwarkesh.pricelist.v92` હતી — એ જુદી એપ છે. આ એકીકૃત પ્રોજેક્ટ **V9 app ID** રાખે છે. પરંતુ GitHub Debug APKને અગાઉ દર બિલ્ડમાં અલગ Android Debug signing key મળી હોય છે. Android અપડેટ માટે App ID **અને** Signing Certificate બંને મેચ થવા જોઈએ.

તમારી હાલની APK પર `App not installed: package conflicts` દેખાય તો **હમણાં uninstall ન કરો**:
1. જૂની V9 એપમાં Sales Hub → Backup → Full JSON Backup લો.
2. માસિક બેકઅપ અને Business Profile/Leads સાચા છે તે તપાસો; Cloudમાં Products/Leads ખરેખર છે તે ચકાસો.
3. પછી જ જૂની V9 debug uninstall કરીને આ signed version install કરો; JSON Restore અને Cloud Merge કરો.
4. **કાયમી Updates** માટે ખાનગી release Keystore બનાવવી અને GitHub Actions Secretsમાં રાખવી; તે જ key તમામ આગળના releases માટે જાળવવી જરૂરી છે.
5. અલગ V9.2 એપ હોય તો તેનું પણ અલગ Backup લો. જૂની એપ તરત delete ન કરવી.

કોઈ પણ સમયે Source ZIPમાં Keystore, API Secret, Service Role Key કે Password મૂકાશે નહીં.

## 3) GitHubમાં Android Source Upload

તમારા Repository `dhruvnayakofficial/dwarkesh-CRM` માં:
1. `Dwarkesh_Business_OS_V10_1_UPDATED_Source.zip` ને Repository **root** માં Upload/Commit કરો (Extract કરવાની જરૂર નથી).
2. `.github/workflows/build.yml` ને આ પેકેજની `build.yml` ફાઇલના લખાણથી બદલો અને Commit કરો.
3. **Actions → Build Dwarkesh Business OS V10.1 APK** → Run workflow.
4. સફળ થાય તો `Dwarkesh-OS-V10-1-TEST-APK` Artifactમાં debug APK આવે. **Test APK permanent in-place updates માટે નથી.**
5. Release Keyના Secrets નાખેલા હોય તો `Dwarkesh-OS-V10-1-RELEASE-APK` પણ આવશે.
6. Android SDK 35 માટે જૂના `android-actions/setup-android@v3` actionની જરૂર નથી; GitHub hosted runnerનું SDK વપરાય છે.

### Permanent Release Signing – એક વખત સેટ કરવાની
તમારા નિયંત્રણવાળા વિશ્વસનીય PC પર `keytool` થી ખાનગી `.jks` બનાવો. Keystore અને તેનો password offline backup રાખો. GitHub Repository → Settings → Secrets and variables → Actions માં નીચેના secrets સેટ કરો:

- `DWARKESH_KEYSTORE_BASE64` — JKS fileનું **single-line base64**
- `DWARKESH_KEYSTORE_PASSWORD`
- `DWARKESH_KEY_ALIAS`
- `DWARKESH_KEY_PASSWORD`

આ વિગતો ChatGPT, GitHub commit કે Staffને મોકલશો નહીં. Keystore ગુમ થશે તો in-place future updates અટકી શકે. Existing Debug buildની signing keyથી release update શક્ય ન પણ હોય — one-time backup + migration જરૂરી છે.

## 4) Cloud Setup / Gemini staff

Supabase પહેલાનું Project જ રાખો. **SQL Editor → New Query** માં `supabase/v10_growth_os.sql` Run કરો. આ ફાઇલ જૂના products/workspaces/leads drop કરતી નથી. Supabase RLS સાથે `os_records` બનાવે છે. Schemaમાં Owner/Staff પાસે workspace-level access છે; Staffને Purchase Price મંજૂર છે એવી તમારી પસંદગી પ્રમાણે, permissions review કરીને જ production data ભરો.

Cloud & Staffમાં અગાઉ જેવી URL અને Publishable key, user login. Growth OS → Data & Sync → **Push / Pull** (manual). Do not replace all cloud products blindly. Monthly deletion local જ રહે છે; Cloud Cleanup બીજો અલગ flow છે.

Supabase Functions → business-ai deploy માટે function code `supabase/functions/business-ai/index.ts` છે. Supabase Secretsમાં `GEMINI_API_KEY` રાખો, optional `GEMINI_MODEL=gemini-3.8-flash`; function deployed થયા પછી Growth OS → AI Commands → **Cloud Gemini AI**. Customer Price-only product info જ functionને મોકલાય છે. API key APKમાં ન મૂકો. Rate limits / usage policies અને cost monitoring જરૂરી છે. આ live deploy અહીં કરેલું નથી.

## 5) Vyapar Computer + Mobile workflow

Vyapar Computer → Item List/Items/Stock Reports → Excel Export (menu version પર આધારિત). File `.xlsx/.xls/.csv`.

Growth OS → Vyapar → Choose file → Mapping check → **Preview** → Purchase/Customer/Stock ફેરફાર વાંચો → Full Backup લીધાની checkbox → **Approve & Import**.

**Safety:** `Purchase Price` માત્ર `dealer` માં જાય. Vyapar `Sale Price` ગ્રાહક ભાવમાં જાય તે checkbox Default OFF છે. `Closing Stock` Update પણ Default OFF છે. Exportમાંથી ગાયબ Item **Delete નથી થતો**. Missing Price = Customer Price Pending. New Items માટે Brand/Model mapping ચકાસો. એક જ Model ભિન્ન બ્રાન્ડનું હોય તો અલગ key છે. Invoice/Salesને Vyaparમાં primary ledger માનો.

Sample CSV header `Brand,Item Name,Item Code,Purchase Price,Sale Price,Closing Stock,Category,GST`.

## 6) Service/Leads/Marketing

Sales Hub → Leads CRM યથાવત. Growth OS → Sales/Payments, Suppliers, Service/AMC, Campaigns, Tasksમાં લોકલ records. ઇન્ટરનેટ ન હોય ત્યારે પણ Local Save થાય; Cloud Sync તમારે Push કરવું પડે. WhatsApp message ફક્ત draft/open link છે; **API વગર auto-send નથી**.

## 7) Testing and limits

Sourceનો JavaScript syntax check કર્યો છે, પરંતુ Android Build, live Supabase migration, Vyaparની અસલી Excel file, WhatsApp/Gemini API અને જુદા ફોન પર Updating અહીં end-to-end પરીક્ષણ કરેલ નથી. Productionમાં ઉપયોગ પહેલાં Backup સાથે Test Lead, 2–3 Items, Purchase/Customer Price અને One Invoice Cross-check કરો.

## V10.1 QA સુધારા
- Vyapar Import માટે સક્રિય Admin Cloud Login ફરજિયાત છે.
- Excel/CSV Exportમાં spreadsheet-formula injection ટાળવામાં આવ્યું છે.
- Local Salesમાં Customerથી મળેલી રકમ Total કરતાં વધારે હોય તો સેવ અટકે છે.
- Login વગર Price Managerમાં Admin Edit વિકલ્પ બંધ છે.
- *આ સુરક્ષા સુધારા છે; Live Vyapar API, WhatsApp API અથવા Supabase Secrets પોતાની જાતે કનેક્ટ થયા નથી.*

## Browser QA v10.1
- Local Sale અને Service record Save: PASS (mock browser localStorage).
- Vyapar CSV Preview: PASS, Preview button bug fixed.
- Admin નહીં હોય તો Import Block: PASS.
- Admin-mode Mock સાથે Import: PASS.
- Purchase Price vs Customer Price અને Stock (default OFF): PASS.
- Browserમાં JavaScript Exceptions: 0.
- Android QA APKનું ZIP અને signature self-verify: PASS, પણ device પર Install Test થયું નથી.
- GitHub signed release / real Vyapar file / Supabase deployment / WhatsApp API: NOT DONE.
