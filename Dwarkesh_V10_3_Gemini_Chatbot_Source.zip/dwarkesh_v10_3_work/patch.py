from pathlib import Path
p=Path('app/src/main/assets/index.html');s=p.read_text()
s=s.replace("'conditioner','way'];for(let [brand", "'conditioner','way','inch','inches','ઇંચ','size','screen','display','સ્માર્ટ','smart'];for(let [brand",1)
s=s.replace("let words=cleaned.split(/[\\s,]+/).filter", "cleaned=cleaned.replace(/\\b\\d{2,3}\\s*(?:inch|inches|ઇંચ|\\\")\\b/gi,' ');let words=cleaned.split(/[\\s,]+/).filter",1)
# insert size match into searchResults (TV size must be grounded in actual product text/model)
s=s.replace("if(f.terms.length){let hay=norm([p.model,p.brand,p.category,p.product,p.notes].join(' '));", "let inchMatch=norm(q).match(/\\b(\\d{2,3})\\s*(?:inch|inches|ઇંચ|\\\")/i);if(inchMatch){let size=inchMatch[1];let phay=norm([p.model,p.product,p.notes,p.specs].join(' '));if(!(new RegExp('(^|[^0-9])'+size+'(?=([^0-9]|$))').test(phay)||new RegExp('(^|[^0-9])'+(Number(size)*2.54).toFixed(0)+'\\s*cm\\b').test(phay)))return false;}if(f.terms.length){let hay=norm([p.model,p.brand,p.category,p.product,p.notes].join(' '));",1)
# add separate CRM top-level floating nav and modal (no WhatsApp auto send)
addition='''
<style>
#wa-crm-launch{position:fixed;right:12px;bottom:88px;z-index:1900;background:#0b7667;color:#fff;border:0;border-radius:16px;padding:13px 16px;box-shadow:0 4px 16px #0004;font-weight:700}
#wa-crm-screen{position:fixed;inset:0;background:#f5f8fa;z-index:2400;display:none;overflow:auto;padding:16px;color:#14263c;font-family:inherit}
#wa-crm-screen.open{display:block}#wa-crm-screen .crm-wrap{max-width:700px;margin:auto}#wa-crm-screen .crm-card{background:white;border:1px solid #dbe4e8;border-radius:14px;padding:14px;margin:12px 0}#wa-crm-screen input,#wa-crm-screen select,#wa-crm-screen textarea{display:block;width:100%;padding:11px;margin:7px 0;border:1px solid #aabcc7;border-radius:8px;box-sizing:border-box}#wa-crm-screen button{padding:10px 12px;border-radius:9px;border:1px solid #b2c4cc;background:#e7f1f4;margin:3px;cursor:pointer}#wa-crm-screen .crm-primary{background:#076c60;color:white}#wa-crm-screen .crm-status{font-size:13px;min-height:22px}#wa-crm-screen .crm-lead{border-top:1px solid #ddd;padding:10px 0}
</style>
<button id="wa-crm-launch" type="button" onclick="dwOpenCRM()">📲 WhatsApp CRM</button>
<section id="wa-crm-screen" aria-label="Independent WhatsApp CRM"><div class="crm-wrap">
<div style="display:flex;justify-content:space-between;align-items:center"><h2>📲 WhatsApp CRM</h2><button onclick="dwCloseCRM()">✕ Close</button></div>
<p>Sales Hubથી અલગ Leads, Follow-ups અને WhatsApp Drafts. Auto Reply માટે અધિકૃત WhatsApp API જોડવું જરૂરી છે.</p>
<div class="crm-card"><h3>➕ Lead / Inquiry</h3><input id="dwcrm-name" placeholder="Customer Name"/><input id="dwcrm-phone" placeholder="WhatsApp Number (10 digits)" inputmode="tel"/><input id="dwcrm-product" placeholder="Product / Model Inquiry"/><select id="dwcrm-stage"><option>New</option><option>Interested</option><option>Quotation</option><option>Follow-up</option><option>Won</option><option>Lost</option></select><input id="dwcrm-date" type="date" aria-label="Follow-up date"/><textarea id="dwcrm-notes" placeholder="Notes / Customer Requirements"></textarea><button class="crm-primary" onclick="dwSaveLead()">💾 Save Lead</button><div id="dwcrm-feedback" class="crm-status" role="status" aria-live="polite"></div></div>
<div class="crm-card"><h3>📋 Leads & Follow-ups</h3><input id="dwcrm-filter" placeholder="Search customer / number / product" oninput="dwRenderLeads()"/><div id="dwcrm-list"></div></div>
<div class="crm-card"><h3>🤖 Automation Setup</h3><p>AI Auto Reply, Inbox Sync, Human Handoff અને Scheduled WhatsApp Messages હજી Connected નથી. આ ફંક્શન માટે Meta-approved WhatsApp API અને સુરક્ષિત backend જરૂરી છે. અહીંના WhatsApp બટનથી માત્ર તમારું તૈયાર કરેલું Draft ખુલે છે; મેસેજ આપમેળે મોકલાતો નથી.</p></div>
</div></section>
<script>
(function(){'use strict';const K='dwarkesh_wa_crm_v1';const el=id=>document.getElementById(id);const clean=x=>String(x||'').trim();const html=x=>clean(x).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));let busy=false;
function read(){try{const a=JSON.parse(localStorage.getItem(K)||'[]');return Array.isArray(a)?a:[]}catch{return []}}
function feedback(msg,error=false){el('dwcrm-feedback').textContent=msg;el('dwcrm-feedback').style.color=error?'#a12020':'#06745a'}
window.dwOpenCRM=function(){el('wa-crm-screen').classList.add('open');dwRenderLeads()};window.dwCloseCRM=function(){el('wa-crm-screen').classList.remove('open')};
window.dwSaveLead=function(){if(busy)return;const name=clean(el('dwcrm-name').value),phone=clean(el('dwcrm-phone').value).replace(/\\D/g,'');if(!name||!(phone.length===10||phone.length===12&&phone.startsWith('91'))){feedback('❌ Customer Name અને માન્ય Indian WhatsApp નંબર જરૂરી છે.',true);return}busy=true;feedback('⏳ Saving Lead...');try{const list=read();list.unshift({id:Date.now()+'-'+Math.random().toString(36).slice(2),name,phone:phone.length===10?'91'+phone:phone,product:clean(el('dwcrm-product').value),stage:el('dwcrm-stage').value,date:el('dwcrm-date').value,notes:clean(el('dwcrm-notes').value),created:new Date().toISOString()});localStorage.setItem(K,JSON.stringify(list));feedback('✅ Lead Saved — કુલ '+list.length+' Leads');dwRenderLeads();['dwcrm-name','dwcrm-phone','dwcrm-product','dwcrm-notes'].forEach(id=>el(id).value='')}catch(e){feedback('❌ Save failed: '+e.message,true)}finally{busy=false}};
window.dwRenderLeads=function(){const q=clean(el('dwcrm-filter').value).toLowerCase(),a=read().filter(x=>(x.name+' '+x.phone+' '+x.product).toLowerCase().includes(q));el('dwcrm-list').innerHTML=a.length?a.map(x=>{const msg='નમસ્તે '+x.name+', Dwarkesh Enterprise તરફથી '+(x.product||'તમારી Inquiry')+' અંગે સંપર્ક કરી રહ્યા છીએ.';return '<div class="crm-lead"><b>'+html(x.name)+'</b> · '+html(x.phone)+'<div>'+html(x.product)+' · '+html(x.stage)+' · Follow-up: '+html(x.date||'Not set')+'</div><div>'+html(x.notes)+'</div><button data-wa="'+html(x.id)+'">💬 WhatsApp Draft</button><button data-del="'+html(x.id)+'">🗑 Delete</button></div>'}).join(''):'કોઈ Lead મળ્યો નથી.'};
el('dwcrm-list').addEventListener('click',e=>{const b=e.target.closest('button');if(!b)return;const id=b.dataset.wa||b.dataset.del,x=read().find(v=>v.id===id);if(!x)return;if(b.dataset.wa){const msg='નમસ્તે '+x.name+', Dwarkesh Enterprise તરફથી '+(x.product||'તમારી Inquiry')+' અંગે સંપર્ક કરી રહ્યા છીએ.';window.open('https://wa.me/'+x.phone+'?text='+encodeURIComponent(msg),'_blank')}else if(confirm('આ Lead ડિલીટ કરવો છે?')){localStorage.setItem(K,JSON.stringify(read().filter(v=>v.id!==id)));dwRenderLeads()}});
})();
</script>
'''
# inject at end of body, not embedded print string
idx=s.rfind('</body>');assert idx>0;s=s[:idx]+addition+s[idx:]
p.write_text(s)
